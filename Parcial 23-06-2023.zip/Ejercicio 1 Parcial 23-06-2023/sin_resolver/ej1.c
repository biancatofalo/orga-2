#include "ej1.h"

uint32_t* acumuladoPorCliente(uint8_t cantidadDePagos, pago_t* arr_pagos){
    uint32_t *acumClientes = calloc(10, sizeof(uint32_t));
    for (uint8_t i = 0; i<cantidadDePagos; i++) {
        // recorro todos los pagos. Si esta aprobado, lo sumo al acumulado del cliente correspondiente.
        pago_t pagoActual = arr_pagos[i];
        if (pagoActual.aprobado == 1) {
            acumClientes[pagoActual.cliente]+= pagoActual.monto;
        }
    }
    return acumClientes;
}

uint8_t en_blacklist(char* comercio, char** lista_comercios, uint8_t n){
    for (uint8_t i=0; i<n; i++) {
        char *comercio2 = lista_comercios[i];
        if (strcmp(comercio, comercio2)==1) {
            return 1;
        }
    }
    return 0;
}

uint8_t contarEnBlacklist(uint8_t cantidad_pagos, pago_t* arr_pagos, char** arr_comercios, uint8_t size_comercios) {
        uint8_t cant = 0;
        for (uint8_t i = 0; i<cantidad_pagos; i++) {
            if (en_blacklist(arr_pagos[i].comercio, arr_comercios, size_comercios)) {
                cant++;
            }
        }
        return cant;
}

pago_t** blacklistComercios(uint8_t cantidad_pagos, pago_t* arr_pagos, char** arr_comercios, uint8_t size_comercios){
    // si el comercio está en la lista, sumo el pago al arreglo
    // recorro todos los pagos, y para cada uno veo si el comercio está en la blacklist
    // para poder pedir la memoria, tengo que ver cuántos están en la blacklist:
    uint8_t cant = contarEnBlacklist(cantidad_pagos, arr_pagos, arr_comercios, size_comercios);
    pago_t** arreglo = malloc(cant* sizeof(pago_t*));
    uint8_t acum = 0;
    for (uint8_t i = 0; i<cantidad_pagos; i++) {
        if (en_blacklist(arr_pagos[i].comercio, arr_comercios, size_comercios)) {
            arreglo[acum] = &arr_pagos[i];
            acum++;
        }
    }
    return arreglo;
}

/*
uint8_t strCmp (char* comercio1, char* comercio 2) {
    int res = 0;
    uint8_t i = 0;
    while (comercio1[i]!= '\0' && comercio2[i]!= '\0') {
        if (comercio1[i]!=comercio2[i]) {
            res = 1;
            return res;
        }
        i++;
    }
    if (comercio1[i]=='\0' && comercio2[i]=='\0') {
        res = 0;
    } else {
        res = 1;
    }
    return res;
}
 */




