#include "ej1.h"

uint32_t cuantosTemplosClasicos_c(templo *temploArr, size_t temploArr_len){
    uint32_t cant = 0;
    for (size_t i=0; i<temploArr_len; i++) {
        if (temploArr[i].colum_largo==(temploArr[i].colum_corto*2)+1) {
            cant++;
        }
    }
    return cant;
}
  
templo* templosClasicos_c(templo *temploArr, size_t temploArr_len){
    templo *clasicos = malloc(cuantosTemplosClasicos_c(temploArr, temploArr_len)*sizeof(temploArr->nombre));
    uint32_t clasicosAcum = 0;
    for (size_t i=0; i<temploArr_len; i++) {
        if (temploArr[i].colum_largo==(temploArr[i].colum_corto*2)+1) {
            clasicos[clasicosAcum] = temploArr[i].nombre;
            clasicosAcum++;
        }
    }
}
