#include "ej1.h"

char** agrupar_c(msg_t* msgArr, size_t msgArr_len){
    // Primero recorro para ver la maxima etiqueta
    int max = 0;
    size t i = 0;
    while (i<msgArr_len) {
        if (msgArr[i].tag>max) {
            max = msgArr[i].tag;
        }
    }
    char* *array = malloc(max, sizeof(char*)); //pedi memoria para el arreglo
    //ahora tengo que pedir memoria para cada arreglo de cada tag
    // para cada tag: recorro todos los mensajes, cuento, los vuelvo a recorrer y los concateno
    for (size_t i = 0; i < max )

}
